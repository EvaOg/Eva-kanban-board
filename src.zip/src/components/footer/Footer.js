import styles from "../Components.module.css";
import CardContext from "../home/CardContext";
import { useContext } from "react";

const Footer = () => {
  const { cards } = useContext(CardContext);

  // make an var with finished cards!

  return (
    <footer className={styles.footer}>
      <div>
        Active tasks: {cards.length} Finished tasks: {cards.length}{" "}
      </div>
      <div className={styles.footerP2}>Kanban board by Eva, 2023</div>
    </footer>
  );
};

export default Footer;
