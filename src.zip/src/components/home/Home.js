import { useContext, useState, useEffect } from "react";
import styles from "../Components.module.css";

import Header from "./Header";
import NewCardInput from "./NewCardInput";
import CardsList from "./CardsList";
import Option from "./Option";
import CardContext from "./CardContext";
import Button from "./Button";

function Home() {
  const [isAddingNewCardActive, setIsAddingNewCardActive] = useState(true);
  const [optionListReady, setOptionListReady] = useState(false);
  const [component, setComponent] = useState([]);
  const { cards } = useContext(CardContext);

  const cardsNumberStatusBacklog = cards.filter(
    (card) => card.status === "backlog"
  ).length;

  function addCardButtonHandler() {
    setComponent(["create component"]);
    setIsAddingNewCardActive(!isAddingNewCardActive);
  }

  return (
    <div className={styles.home}>
      <div className={styles.block}>
        <Header headerName={"Backlog"} />
        <div className={styles.cardsList}>
          <CardsList status={"backlog"} />

          {component.map((item, i) => (
            <NewCardInput
              changeComponentState={() => setComponent([])}
              setIsAddingNewCardActive={() =>
                setIsAddingNewCardActive(!isAddingNewCardActive)
              }
            />
          ))}

          {isAddingNewCardActive && (
            <Button
              className={styles.btnaddCard}
              onClick={addCardButtonHandler}
            />
          )}
        </div>
      </div>

      <div className={styles.block}>
        <Header headerName={"Ready"} />
        <div className={styles.cardsList}>
          <CardsList status={"ready"} />
          {cardsNumberStatusBacklog > 0 && (
            <Button
              className={styles.btnaddCard}
              onClick={() => setOptionListReady(!optionListReady)}
            />
          )}
          {optionListReady && (
            <Option
              status={"backlog"}
              newStatus={"ready"}
              // setOptionListReady={setOptionListReady(!optionListReady)}
            />
          )}
        </div>
      </div>
    </div>
  );
}
export default Home;
